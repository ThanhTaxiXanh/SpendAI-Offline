// lib/domain/intelligence/voice_parser.dart
import 'package:uuid/uuid.dart';

class VoiceTransactionParser {
  static const Map<String, String> _amountPatterns = {
    'mười': '10',
    'hai mươi': '20',
    'ba mươi': '30',
    'bốn mươi': '40',
    'năm mươi': '50',
    'sáu mươi': '60',
    'bảy mươi': '70',
    'tám mươi': '80',
    'chín mươi': '90',
    'một trăm': '100',
    'năm trăm': '500',
    'một nghìn': '1000',
    'mười nghìn': '10000',
    'năm mươi nghìn': '50000',
    'một trăm nghìn': '100000',
    'năm trăm nghìn': '500000',
    'một triệu': '1000000',
    'năm triệu': '5000000',
    'mười triệu': '10000000',
  };

  static const Map<String, String> _categoryKeywords = {
    'ăn': 'food',
    'cơm': 'food',
    'cà phê': 'coffee',
    'nước': 'drinks',
    'xe': 'transport',
    'xăng': 'transport',
    'taxi': 'transport',
    'siêu thị': 'shopping',
    'mua sắm': 'shopping',
    'quần áo': 'shopping',
    'điện': 'utilities',
    'nước': 'utilities',
    'internet': 'utilities',
    'hóa đơn': 'bills',
    'tiền': 'payment',
    'lương': 'salary',
    'thưởng': 'bonus',
    'tiết kiệm': 'savings',
    'đầu tư': 'investment',
    'giải trí': 'entertainment',
    'phim': 'entertainment',
    'game': 'entertainment',
    'thể dục': 'health',
    'gym': 'health',
    'dược phẩm': 'health',
    'học tập': 'education',
    'sách': 'education',
    'khóa học': 'education',
  };

  static ParsedTransaction? parse(String text) {
    try {
      final normalized = _normalize(text);
      print('🎙️ Normalized: $normalized');

      // Extract amount
      final amount = _extractAmount(normalized);
      if (amount == null || amount <= 0) {
        return null;
      }

      // Extract category
      final category = _extractCategory(normalized);

      // Extract wallet (simple: nếu có "tiền mặt" -> cash, ngược lại -> default)
      final wallet = _extractWallet(normalized);

      // Extract date (mặc định hôm nay)
      final date = DateTime.now();

      // Extract note
      final note = _extractNote(normalized);

      // Detect transaction type (mặc định expense)
      final type = _detectTransactionType(normalized);

      return ParsedTransaction(
        id: const Uuid().v4(),
        amount: amount,
        category: category,
        wallet: wallet,
        date: date,
        note: note,
        type: type,
        confidence: _calculateConfidence(normalized),
      );
    } catch (e) {
      print('❌ Parse error: $e');
      return null;
    }
  }

  static String _normalize(String text) {
    return text
        .toLowerCase()
        .replaceAll(RegExp(r'[^\w\s]'), '')
        .trim();
  }

  static int? _extractAmount(String text) {
    // Try direct number first
    final directMatch = RegExp(r'(\d+)').firstMatch(text);
    if (directMatch != null) {
      final num = int.tryParse(directMatch.group(1)!);
      if (num != null && num > 0) return num;
    }

    // Try pattern matching
    for (final entry in _amountPatterns.entries) {
      if (text.contains(entry.key)) {
        return int.parse(entry.value);
      }
    }

    return null;
  }

  static String _extractCategory(String text) {
    for (final entry in _categoryKeywords.entries) {
      if (text.contains(entry.key)) {
        return entry.value;
      }
    }
    return 'other';
  }

  static String _extractWallet(String text) {
    if (text.contains('tiền mặt') || text.contains('cash')) {
      return 'cash';
    }
    if (text.contains('thẻ') || text.contains('card')) {
      return 'credit_card';
    }
    return 'default';
  }

  static String? _extractNote(String text) {
    // Remove numbers and known keywords to get note
    final parts = text.split(RegExp(r'\d+'));
    if (parts.length > 1) {
      return parts.join(' ').trim();
    }
    return null;
  }

  static String _detectTransactionType(String text) {
    if (text.contains('lương') || text.contains('thưởng') || text.contains('thu nhập')) {
      return 'income';
    }
    if (text.contains('chuyển') || text.contains('transfer')) {
      return 'transfer';
    }
    return 'expense';
  }

  static double _calculateConfidence(String text) {
    // Check if text contains both amount and category
    double confidence = 0.5;

    if (RegExp(r'\d+').hasMatch(text)) confidence += 0.25;
    if (_categoryKeywords.keys.any((k) => text.contains(k))) confidence += 0.15;
    if (text.split(' ').length > 2) confidence += 0.1;

    return (confidence / 1.0).clamp(0.0, 1.0);
  }
}

class ParsedTransaction {
  final String id;
  final int amount;
  final String category;
  final String wallet;
  final DateTime date;
  final String? note;
  final String type;
  final double confidence;

  ParsedTransaction({
    required this.id,
    required this.amount,
    required this.category,
    required this.wallet,
    required this.date,
    this.note,
    required this.type,
    required this.confidence,
  });

  @override
  String toString() => 'ParsedTransaction('
      'amount: $amount, '
      'category: $category, '
      'wallet: $wallet, '
      'confidence: $confidence)';
}
