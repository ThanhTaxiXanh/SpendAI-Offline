// lib/domain/intelligence/intelligence_engines.dart
import 'dart:math';
import '../../core/entities/transaction.dart';
import '../../core/entities/category.dart';

class BehaviorProfileEngine {
  static Map<String, dynamic> analyzeBehavior(List<Transaction> transactions, String categoryId) {
    final categoryTransactions = transactions
        .where((t) => t.categoryId == categoryId && t.type == TransactionType.expense)
        .toList();

    if (categoryTransactions.isEmpty) {
      return {'avgAmount': 0, 'frequency': 0, 'riskScore': 0.0};
    }

    final avgAmount = (categoryTransactions.fold<int>(
          0,
          (sum, t) => sum + t.amount,
        ) /
        categoryTransactions.length)
        .toInt();
    final frequency = categoryTransactions.length;

    // Risk score based on average and frequency (0.0 - 1.0)
    final baselineRisk = min(avgAmount.toDouble() / 100000, 1.0);
    final frequencyRisk = min(frequency.toDouble() / 30, 1.0);
    final riskScore = (baselineRisk * 0.6 + frequencyRisk * 0.4);

    return {
      'avgAmount': avgAmount,
      'frequency': frequency,
      'riskScore': riskScore,
    };
  }
}

class RecurringDetectionEngine {
  static Map<String, dynamic>? detectRecurring(
    List<Transaction> transactions,
    String categoryId,
  ) {
    final categoryTransactions = transactions
        .where((t) => t.categoryId == categoryId && t.type == TransactionType.expense)
        .toList();

    if (categoryTransactions.length < 3) return null;

    // Sort by date
    categoryTransactions.sort((a, b) => a.date.compareTo(b.date));

    // Calculate intervals between transactions
    final intervals = <int>[];
    for (int i = 1; i < categoryTransactions.length; i++) {
      final diff = categoryTransactions[i].date.difference(categoryTransactions[i - 1].date).inDays;
      intervals.add(diff);
    }

    if (intervals.isEmpty) return null;

    // Find most common interval
    final frequencyMap = <int, int>{};
    for (final interval in intervals) {
      frequencyMap[interval] = (frequencyMap[interval] ?? 0) + 1;
    }

    final mostCommonInterval =
        frequencyMap.entries.reduce((a, b) => a.value > b.value ? a : b).key;
    final avgAmount =
        (categoryTransactions.fold<int>(0, (sum, t) => sum + t.amount) ~/ categoryTransactions.length);

    // Determine frequency name
    late String frequency;
    if (mostCommonInterval <= 7) {
      frequency = 'weekly';
    } else if (mostCommonInterval <= 15) {
      frequency = 'bi-weekly';
    } else if (mostCommonInterval <= 35) {
      frequency = 'monthly';
    } else {
      return null;
    }

    // Calculate confidence based on consistency
    final stdDev = _calculateStdDev(intervals.cast<double>());
    final avgInterval = intervals.fold<double>(0, (a, b) => a + b) / intervals.length;
    final confidence = max(0.0, 1.0 - (stdDev / avgInterval));

    return {
      'frequency': frequency,
      'avgAmount': avgAmount,
      'nextExpected': categoryTransactions.last.date.add(Duration(days: mostCommonInterval)),
      'confidence': confidence,
      'interval': mostCommonInterval,
    };
  }

  static double _calculateStdDev(List<double> values) {
    if (values.isEmpty) return 0;
    final mean = values.fold<double>(0, (a, b) => a + b) / values.length;
    final variance = values.fold<double>(0, (sum, val) => sum + pow(val - mean, 2).toDouble()) / values.length;
    return sqrt(variance);
  }
}

class AnomalyDetectionEngine {
  static Map<String, dynamic>? detectAnomaly(
    List<Transaction> transactions,
    String categoryId,
    {int lookbackDays = 30,}
  ) {
    final now = DateTime.now();
    final lookbackDate = now.subtract(Duration(days: lookbackDays));

    final recentTransactions = transactions
        .where((t) =>
            t.categoryId == categoryId &&
            t.type == TransactionType.expense &&
            t.date.isAfter(lookbackDate) &&
            t.date.isBefore(now))
        .toList();

    if (recentTransactions.length < 3) return null;

    // Calculate baseline average
    final amounts = recentTransactions.map((t) => t.amount.toDouble()).toList();
    final baseline = amounts.fold<double>(0, (a, b) => a + b) / amounts.length;

    // Get latest transaction
    recentTransactions.sort((a, b) => b.date.compareTo(a.date));
    final latest = recentTransactions.first.amount.toDouble();

    // Check if it's an outlier (> 2 sigma)
    final stdDev = RecurringDetectionEngine._calculateStdDev(amounts);
    final zScore = (latest - baseline) / stdDev;

    if (zScore > 2.0) {
      return {
        'anomalyType': 'spike',
        'amount': latest.toInt(),
        'baseline': baseline.toInt(),
        'zScore': zScore,
        'severity': min(1.0, zScore / 5.0),
        'message': 'شراء غير عادي في هذه الفئة',
      };
    }

    return null;
  }
}

class BudgetRiskPredictor {
  static double calculateOverspendingProbability(
    List<Transaction> transactions,
    String categoryId,
    int monthlyBudget,
    {int daysIntoMonth = 15,}
  ) {
    final now = DateTime.now();
    final monthStart = DateTime(now.year, now.month, 1);
    final monthTransactions = transactions
        .where((t) =>
            t.categoryId == categoryId &&
            t.type == TransactionType.expense &&
            t.date.isAfter(monthStart) &&
            t.date.isBefore(now))
        .toList();

    final spent = monthTransactions.fold<int>(0, (sum, t) => sum + t.amount);
    final daysRemaining = DateTime(now.year, now.month + 1, 0).day - daysIntoMonth;

    if (daysRemaining <= 0) return spent > monthlyBudget ? 1.0 : 0.0;

    // Estimate remaining spend
    final dailyRate = spent / daysIntoMonth;
    final estimatedTotal = spent + (dailyRate * daysRemaining);

    // Calculate probability using logistic function
    final exponent = -(estimatedTotal - monthlyBudget) / (monthlyBudget * 0.1);
    final probability = 1.0 / (1.0 + exp(exponent));

    return min(1.0, max(0.0, probability));
  }
}

class SpendingForecastEngine {
  static int forecastEndOfMonthBalance(
    List<Transaction> transactions,
    String walletId,
    int currentBalance,
    {int daysIntoMonth = 15,}
  ) {
    final now = DateTime.now();
    final monthStart = DateTime(now.year, now.month, 1);
    final monthEnd = DateTime(now.year, now.month + 1, 0);

    final monthTransactions = transactions
        .where((t) =>
            t.walletId == walletId && t.date.isAfter(monthStart) && t.date.isBefore(now))
        .toList();

    final netFlow = monthTransactions.fold<int>(0, (sum, t) {
      if (t.type == TransactionType.income) return sum + t.amount;
      if (t.type == TransactionType.expense) return sum - t.amount;
      return sum;
    });

    final daysRemaining = monthEnd.day - daysIntoMonth;
    if (daysRemaining <= 0) return currentBalance + netFlow;

    // Linear regression forecast
    final dailyRate = netFlow / daysIntoMonth;
    final projectedFlow = dailyRate * monthEnd.day;

    return currentBalance + projectedFlow.toInt();
  }
}

class InsightGenerator {
  static List<Map<String, dynamic>> generateInsights(
    List<Transaction> transactions,
    List<Category> categories,
    int monthlyBudget,
  ) {
    final insights = <Map<String, dynamic>>[];
    final now = DateTime.now();
    final monthStart = DateTime(now.year, now.month, 1);

    // Analyze each expense category
    for (final category in categories.where((c) => c.type == CategoryType.expense)) {
      // Check for anomalies
      final anomaly = AnomalyDetectionEngine.detectAnomaly(transactions, category.id);
      if (anomaly != null && anomaly['severity'] > 0.5) {
        insights.add({
          'category': 'warning',
          'priority': 3,
          'message': '⚠️ Chi tiêu bất thường ở ${category.name}: ${anomaly['amount']}đ (cao hơn ${(anomaly['baseline'] as int)}đ)',
        });
      }

      // Check for recurring patterns
      final recurring = RecurringDetectionEngine.detectRecurring(transactions, category.id);
      if (recurring != null && recurring['confidence'] > 0.7) {
        insights.add({
          'category': 'info',
          'priority': 1,
          'message': '📊 Chi phí định kỳ ${category.name}: ~${recurring['avgAmount']}đ mỗi ${recurring['frequency']}',
        });
      }

      // Check overspending risk
      const categoryBudget = 5000000; // Example: 5M per category
      final riskProb = BudgetRiskPredictor.calculateOverspendingProbability(
        transactions,
        category.id,
        categoryBudget,
      );
      if (riskProb > 0.7) {
        insights.add({
          'category': 'warning',
          'priority': 2,
          'message': '🚨 Có ${(riskProb * 100).toStringAsFixed(0)}% khả năng vượt chi tiêu ${category.name}',
        });
      }
    }

    // Sort by priority
    insights.sort((a, b) => (b['priority'] as int).compareTo(a['priority'] as int));
    return insights.take(5).toList();
  }
}
