// lib/data/database/app_database.dart
import 'package:drift/drift.dart';
import 'package:flutter/foundation.dart';
import 'package:sqlite3_flutter_libs/sqlite3_flutter_libs.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';
import 'package:drift/native.dart';

// Tables
class Wallets extends Table {
  TextColumn get id => text()();
  TextColumn get name => text()();
  TextColumn get currency => text().withDefault(const Constant('VND'))();
  IntColumn get balance => integer().withDefault(const Constant(0))();
  TextColumn get icon => text().withDefault(const Constant('💰'))();
  BoolColumn get isVisible => boolean().withDefault(const Constant(true))();
  DateTimeColumn get createdAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
  
  @override
  List<Set<Column>> get uniqueKeys => [
    {name},
  ];
}

class Categories extends Table {
  TextColumn get id => text()();
  TextColumn get name => text()();
  TextColumn get type => text()(); // 'income' or 'expense'
  TextColumn get icon => text()();
  TextColumn get color => text()();
  DateTimeColumn get createdAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
}

class Transactions extends Table {
  TextColumn get id => text()();
  TextColumn get walletId => text()();
  TextColumn get categoryId => text().nullable()();
  TextColumn get type => text()(); // 'expense', 'income', 'transfer'
  IntColumn get amount => integer()();
  TextColumn get currency => text().withDefault(const Constant('VND'))();
  DateTimeColumn get date => dateTime()();
  TextColumn get note => text().nullable()();
  TextColumn get relatedWalletId => text().nullable()();
  DateTimeColumn get createdAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
  
  @override
  List<Index> get indexes => [
    Index('idx_wallet_date', [walletId, date]),
    Index('idx_category_date', [categoryId, date]),
  ];
}

class LunarEvents extends Table {
  TextColumn get id => text()();
  TextColumn get title => text()();
  TextColumn get type => text()(); // 'solar' or 'lunar'
  DateTimeColumn get solarDate => dateTime()();
  IntColumn get lunarDay => integer().nullable()();
  IntColumn get lunarMonth => integer().nullable()();
  IntColumn get lunarYear => integer().nullable()();
  TextColumn get description => text().nullable()();
  IntColumn get notifyDaysBefore => integer().withDefault(const Constant(0))();
  DateTimeColumn get createdAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
}

class CryptoWatchlist extends Table {
  TextColumn get id => text()();
  TextColumn get coinId => text(); // CoinGecko ID
  TextColumn get name => text()();
  TextColumn get symbol => text()();
  RealColumn get price => real()();
  RealColumn get change24h => real()();
  DateTimeColumn get lastUpdated => dateTime()();
  DateTimeColumn get createdAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
  
  @override
  List<Set<Column>> get uniqueKeys => [
    {coinId},
  ];
}

class BehaviorProfiles extends Table {
  TextColumn get id => text()();
  TextColumn get categoryId => text()();
  IntColumn get avgAmount => integer()();
  IntColumn get frequency => integer().withDefault(const Constant(1))();
  RealColumn get riskScore => real().withDefault(const Constant(0.0))();
  DateTimeColumn get lastUpdated => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
}

class RecurringPatterns extends Table {
  TextColumn get id => text()();
  TextColumn get categoryId => text()();
  IntColumn get avgAmount => integer()();
  TextColumn get frequency => text(); // 'daily', 'weekly', 'monthly'
  DateTimeColumn get lastDetected => dateTime()();
  RealColumn get confidence => real()();
  DateTimeColumn get createdAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
}

class AnomalyLogs extends Table {
  TextColumn get id => text()();
  TextColumn get categoryId => text()();
  TextColumn get anomalyType => text(); // 'spike', 'unusual'
  IntColumn get amount => integer()();
  RealColumn get severity => real();
  DateTimeColumn get detectedAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
}

class Insights extends Table {
  TextColumn get id => text()();
  TextColumn get message => text()();
  TextColumn get category => text(); // 'warning', 'suggestion', 'info'
  IntColumn get priority => integer().withDefault(const Constant(0))();
  BoolColumn get isRead => boolean().withDefault(const Constant(false))();
  DateTimeColumn get createdAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
}

class PluginRegistry extends Table {
  TextColumn get id => text()();
  TextColumn get name => text()();
  TextColumn get version => text()();
  BoolColumn get isEnabled => boolean().withDefault(const Constant(true))();
  TextColumn get metadata => text().nullable()();
  DateTimeColumn get installedAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
}

class FeatureFlags extends Table {
  TextColumn get id => text()();
  TextColumn get name => text()();
  BoolColumn get isEnabled => boolean().withDefault(const Constant(false))();
  TextColumn get description => text().nullable()();
  DateTimeColumn get createdAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
  
  @override
  List<Set<Column>> get uniqueKeys => [
    {name},
  ];
}

@DriftDatabase(tables: [
  Wallets,
  Categories,
  Transactions,
  LunarEvents,
  CryptoWatchlist,
  BehaviorProfiles,
  RecurringPatterns,
  AnomalyLogs,
  Insights,
  PluginRegistry,
  FeatureFlags,
])
class AppDatabase extends _$AppDatabase {
  AppDatabase() : super(_openConnection());

  @override
  int get schemaVersion => 1;

  @override
  MigrationStrategy get migration => MigrationStrategy(
    beforeOpen: (details) async {
      await customStatement('PRAGMA foreign_keys = ON');
    },
  );

  // Wallet queries
  Future<List<WalletsCompanion>> getAllWallets() {
    return (select(wallets)).get() as Future<List<WalletsCompanion>>;
  }

  Future<int> insertWallet(WalletsCompanion wallet) {
    return into(wallets).insert(wallet);
  }

  Future<bool> updateWallet(WalletsCompanion wallet) {
    return update(wallets).replace(wallet);
  }

  Future<int> deleteWallet(String walletId) {
    return (delete(wallets)..where((w) => w.id.equals(walletId))).go();
  }

  // Category queries
  Future<List<CategoriesCompanion>> getAllCategories() {
    return (select(categories)).get() as Future<List<CategoriesCompanion>>;
  }

  Future<int> insertCategory(CategoriesCompanion category) {
    return into(categories).insert(category);
  }

  Future<bool> updateCategory(CategoriesCompanion category) {
    return update(categories).replace(category);
  }

  // Transaction queries
  Future<List<TransactionsCompanion>> getTransactionsByWallet(String walletId) {
    return (select(transactions)..where((t) => t.walletId.equals(walletId)))
        .get() as Future<List<TransactionsCompanion>>;
  }

  Future<List<TransactionsCompanion>> getTransactionsByDate(
      DateTime startDate, DateTime endDate) {
    return (select(transactions)
          ..where((t) => t.date.isBetweenValues(startDate, endDate)))
        .get() as Future<List<TransactionsCompanion>>;
  }

  Future<int> insertTransaction(TransactionsCompanion transaction) {
    return into(transactions).insert(transaction);
  }

  Future<bool> updateTransaction(TransactionsCompanion transaction) {
    return update(transactions).replace(transaction);
  }

  Future<int> deleteTransaction(String transactionId) {
    return (delete(transactions)..where((t) => t.id.equals(transactionId))).go();
  }

  // Lunar event queries
  Future<List<LunarEventsCompanion>> getLunarEventsForDate(DateTime date) {
    final startOfDay = DateTime(date.year, date.month, date.day);
    final endOfDay = startOfDay.add(const Duration(days: 1));
    return (select(lunarEvents)
          ..where((e) => e.solarDate.isBetweenValues(startOfDay, endOfDay)))
        .get() as Future<List<LunarEventsCompanion>>;
  }

  Future<int> insertLunarEvent(LunarEventsCompanion event) {
    return into(lunarEvents).insert(event);
  }

  Future<bool> updateLunarEvent(LunarEventsCompanion event) {
    return update(lunarEvents).replace(event);
  }

  Future<int> deleteLunarEvent(String eventId) {
    return (delete(lunarEvents)..where((e) => e.id.equals(eventId))).go();
  }

  // Crypto watchlist queries
  Future<List<CryptoWatchlistCompanion>> getAllCryptos() {
    return (select(cryptoWatchlist)).get() as Future<List<CryptoWatchlistCompanion>>;
  }

  Future<int> insertCrypto(CryptoWatchlistCompanion crypto) {
    return into(cryptoWatchlist).insert(crypto);
  }

  Future<bool> updateCrypto(CryptoWatchlistCompanion crypto) {
    return update(cryptoWatchlist).replace(crypto);
  }

  Future<int> deleteCrypto(String cryptoId) {
    return (delete(cryptoWatchlist)..where((c) => c.id.equals(cryptoId))).go();
  }

  // Insight queries
  Future<List<InsightsCompanion>> getUnreadInsights() {
    return (select(insights)..where((i) => i.isRead.equals(false)))
        .get() as Future<List<InsightsCompanion>>;
  }

  Future<int> insertInsight(InsightsCompanion insight) {
    return into(insights).insert(insight);
  }

  Future<bool> markInsightAsRead(String insightId) {
    return (update(insights)..where((i) => i.id.equals(insightId)))
        .write(const InsightsCompanion(isRead: Value(true)));
  }
}

LazyDatabase _openConnection() {
  return LazyDatabase(() async {
    final dbFolder = await getApplicationDocumentsDirectory();
    final file = File('${dbFolder.path}/spendai.db');
    if (kDebugMode) {
      await applyCustomUserPermissions(file);
    }
    return NativeDatabase.createInBackground(file);
  });
}
