// lib/data/repositories/wallet_repository.dart
import 'package:uuid/uuid.dart';
import '../../core/entities/wallet.dart';
import '../database/app_database.dart';

class WalletRepository {
  final AppDatabase database;

  WalletRepository(this.database);

  Future<List<Wallet>> getAllWallets() async {
    final walletRows = await database.getAllWallets();
    return walletRows.map((row) => _toEntity(row)).toList();
  }

  Future<Wallet?> getWallet(String id) async {
    final query = database.select(database.wallets)
      ..where((w) => w.id.equals(id));
    final result = await query.getSingleOrNull();
    return result != null ? _toEntity(result) : null;
  }

  Future<String> createWallet({
    required String name,
    required String currency,
    required String icon,
  }) async {
    final id = const Uuid().v4();
    final now = DateTime.now();

    await database.into(database.wallets).insert(
      WalletsCompanion(
        id: Value(id),
        name: Value(name),
        currency: Value(currency),
        balance: const Value(0),
        icon: Value(icon),
        isVisible: const Value(true),
        createdAt: Value(now),
      ),
    );
    return id;
  }

  Future<void> updateWallet({
    required String id,
    String? name,
    int? balance,
    String? icon,
    bool? isVisible,
  }) async {
    final wallet = await getWallet(id);
    if (wallet == null) return;

    await database.update(database.wallets).replace(
      WalletsCompanion(
        id: Value(wallet.id),
        name: Value(name ?? wallet.name),
        currency: Value(wallet.currency),
        balance: Value(balance ?? wallet.balance),
        icon: Value(icon ?? wallet.icon),
        isVisible: Value(isVisible ?? wallet.isVisible),
        createdAt: Value(wallet.createdAt),
      ),
    );
  }

  Future<void> updateBalance(String walletId, int newBalance) async {
    await database.update(database.wallets).replace(
      WalletsCompanion(
        id: Value(walletId),
        balance: Value(newBalance),
      ),
    );
  }

  Future<void> deleteWallet(String id) async {
    await database.deleteWallet(id);
  }

  Future<int> getTotalBalance() async {
    final wallets = await getAllWallets();
    return wallets.fold(0, (sum, w) => sum + w.balance);
  }

  Wallet _toEntity(Wallet row) => row;
}

// lib/data/repositories/category_repository.dart
import '../../core/entities/category.dart';

class CategoryRepository {
  final AppDatabase database;

  CategoryRepository(this.database);

  Future<List<Category>> getAllCategories() async {
    final rows = await database.getAllCategories();
    return rows.map((row) => _toEntity(row)).toList();
  }

  Future<List<Category>> getCategoriesByType(CategoryType type) async {
    final query = database.select(database.categories)
      ..where((c) => c.type.equals(type.toString().split('.').last));
    final results = await query.get();
    return results.map((row) => _toEntity(row)).toList();
  }

  Future<String> createCategory({
    required String name,
    required CategoryType type,
    required String icon,
    required String color,
  }) async {
    final id = const Uuid().v4();
    final now = DateTime.now();

    await database.into(database.categories).insert(
      CategoriesCompanion(
        id: Value(id),
        name: Value(name),
        type: Value(type.toString().split('.').last),
        icon: Value(icon),
        color: Value(color),
        createdAt: Value(now),
      ),
    );
    return id;
  }

  Future<void> updateCategory({
    required String id,
    String? name,
    String? icon,
    String? color,
  }) async {
    final query = database.select(database.categories)
      ..where((c) => c.id.equals(id));
    final existing = await query.getSingleOrNull();
    if (existing == null) return;

    await database.update(database.categories).replace(
      CategoriesCompanion(
        id: Value(existing.id),
        name: Value(name ?? existing.name),
        type: Value(existing.type),
        icon: Value(icon ?? existing.icon),
        color: Value(color ?? existing.color),
        createdAt: Value(existing.createdAt),
      ),
    );
  }

  Future<void> deleteCategory(String id) async {
    await (database.delete(database.categories)
          ..where((c) => c.id.equals(id)))
        .go();
  }

  Category _toEntity(Category row) => row;
}

// lib/data/repositories/transaction_repository.dart
import '../../core/entities/transaction.dart';

class TransactionRepository {
  final AppDatabase database;

  TransactionRepository(this.database);

  Future<List<Transaction>> getTransactionsByWallet(String walletId) async {
    final query = database.select(database.transactions)
      ..where((t) => t.walletId.equals(walletId))
      ..orderBy([(t) => OrderingTerm(expression: t.date, mode: OrderingMode.desc)]);
    final results = await query.get();
    return results.map((row) => _toEntity(row)).toList();
  }

  Future<List<Transaction>> getTransactionsByDateRange(
    DateTime startDate,
    DateTime endDate, {
    String? walletId,
    String? categoryId,
  }) async {
    final query = database.select(database.transactions)
      ..where((t) => t.date.isBetweenValues(startDate, endDate));

    if (walletId != null) {
      query.where((t) => t.walletId.equals(walletId));
    }
    if (categoryId != null) {
      query.where((t) => t.categoryId.equals(categoryId));
    }

    query.orderBy([(t) => OrderingTerm(expression: t.date, mode: OrderingMode.desc)]);
    final results = await query.get();
    return results.map((row) => _toEntity(row)).toList();
  }

  Future<String> createTransaction({
    required String walletId,
    required TransactionType type,
    required int amount,
    required String currency,
    required DateTime date,
    String? categoryId,
    String? note,
    String? relatedWalletId,
  }) async {
    final id = const Uuid().v4();
    final now = DateTime.now();

    await database.into(database.transactions).insert(
      TransactionsCompanion(
        id: Value(id),
        walletId: Value(walletId),
        categoryId: categoryId != null ? Value(categoryId) : const Value(null),
        type: Value(type.toString().split('.').last),
        amount: Value(amount),
        currency: Value(currency),
        date: Value(date),
        note: note != null ? Value(note) : const Value(null),
        relatedWalletId: relatedWalletId != null ? Value(relatedWalletId) : const Value(null),
        createdAt: Value(now),
      ),
    );
    return id;
  }

  Future<void> updateTransaction({
    required String id,
    int? amount,
    String? categoryId,
    String? note,
    DateTime? date,
  }) async {
    final query = database.select(database.transactions)
      ..where((t) => t.id.equals(id));
    final existing = await query.getSingleOrNull();
    if (existing == null) return;

    await database.update(database.transactions).replace(
      TransactionsCompanion(
        id: Value(existing.id),
        walletId: Value(existing.walletId),
        categoryId: categoryId != null ? Value(categoryId) : Value(existing.categoryId),
        type: Value(existing.type),
        amount: Value(amount ?? existing.amount),
        currency: Value(existing.currency),
        date: Value(date ?? existing.date),
        note: note != null ? Value(note) : Value(existing.note),
        relatedWalletId: Value(existing.relatedWalletId),
        createdAt: Value(existing.createdAt),
      ),
    );
  }

  Future<void> deleteTransaction(String id) async {
    await database.deleteTransaction(id);
  }

  Future<(int income, int expense)> getSummary(
    DateTime startDate,
    DateTime endDate, {
    String? walletId,
  }) async {
    final transactions = await getTransactionsByDateRange(
      startDate,
      endDate,
      walletId: walletId,
    );

    int income = 0, expense = 0;
    for (final txn in transactions) {
      if (txn.type == TransactionType.income) {
        income += txn.amount;
      } else if (txn.type == TransactionType.expense) {
        expense += txn.amount;
      }
    }

    return (income, expense);
  }

  Transaction _toEntity(Transaction row) => row;
}

// lib/data/repositories/lunar_event_repository.dart
import '../../core/entities/lunar_event.dart';

class LunarEventRepository {
  final AppDatabase database;

  LunarEventRepository(this.database);

  Future<List<LunarEvent>> getEventsForDate(DateTime date) async {
    final startOfDay = DateTime(date.year, date.month, date.day);
    final endOfDay = startOfDay.add(const Duration(days: 1));

    final query = database.select(database.lunarEvents)
      ..where((e) => e.solarDate.isBetweenValues(startOfDay, endOfDay))
      ..orderBy([(e) => OrderingTerm(expression: e.solarDate)]);

    final results = await query.get();
    return results.map((row) => _toEntity(row)).toList();
  }

  Future<List<LunarEvent>> getEventsForMonth(DateTime date) async {
    final startOfMonth = DateTime(date.year, date.month, 1);
    final endOfMonth = DateTime(date.year, date.month + 1, 0);

    final query = database.select(database.lunarEvents)
      ..where((e) => e.solarDate.isBetweenValues(startOfMonth, endOfMonth))
      ..orderBy([(e) => OrderingTerm(expression: e.solarDate)]);

    final results = await query.get();
    return results.map((row) => _toEntity(row)).toList();
  }

  Future<String> createEvent({
    required String title,
    required EventType type,
    required DateTime solarDate,
    int? lunarDay,
    int? lunarMonth,
    int? lunarYear,
    String? description,
    required int notifyDaysBefore,
  }) async {
    final id = const Uuid().v4();
    final now = DateTime.now();

    await database.into(database.lunarEvents).insert(
      LunarEventsCompanion(
        id: Value(id),
        title: Value(title),
        type: Value(type.toString().split('.').last),
        solarDate: Value(solarDate),
        lunarDay: lunarDay != null ? Value(lunarDay) : const Value(null),
        lunarMonth: lunarMonth != null ? Value(lunarMonth) : const Value(null),
        lunarYear: lunarYear != null ? Value(lunarYear) : const Value(null),
        description: description != null ? Value(description) : const Value(null),
        notifyDaysBefore: Value(notifyDaysBefore),
        createdAt: Value(now),
      ),
    );
    return id;
  }

  Future<void> updateEvent({
    required String id,
    String? title,
    DateTime? solarDate,
    String? description,
    int? notifyDaysBefore,
  }) async {
    final query = database.select(database.lunarEvents)
      ..where((e) => e.id.equals(id));
    final existing = await query.getSingleOrNull();
    if (existing == null) return;

    await database.update(database.lunarEvents).replace(
      LunarEventsCompanion(
        id: Value(existing.id),
        title: Value(title ?? existing.title),
        type: Value(existing.type),
        solarDate: Value(solarDate ?? existing.solarDate),
        lunarDay: Value(existing.lunarDay),
        lunarMonth: Value(existing.lunarMonth),
        lunarYear: Value(existing.lunarYear),
        description: description != null ? Value(description) : Value(existing.description),
        notifyDaysBefore: Value(notifyDaysBefore ?? existing.notifyDaysBefore),
        createdAt: Value(existing.createdAt),
      ),
    );
  }

  Future<void> deleteEvent(String id) async {
    await database.deleteLunarEvent(id);
  }

  LunarEvent _toEntity(LunarEvent row) => row;
}
