// lib/core/entities/lunar_event.dart
import 'package:equatable/equatable.dart';

enum EventType { solar, lunar }

class LunarEvent extends Equatable {
  final String id;
  final String title;
  final EventType type;
  final DateTime solarDate;
  final int? lunarDay;
  final int? lunarMonth;
  final int? lunarYear;
  final String? description;
  final int notifyDaysBefore;
  final DateTime createdAt;

  const LunarEvent({
    required this.id,
    required this.title,
    required this.type,
    required this.solarDate,
    this.lunarDay,
    this.lunarMonth,
    this.lunarYear,
    this.description,
    required this.notifyDaysBefore,
    required this.createdAt,
  });

  LunarEvent copyWith({
    String? id,
    String? title,
    EventType? type,
    DateTime? solarDate,
    int? lunarDay,
    int? lunarMonth,
    int? lunarYear,
    String? description,
    int? notifyDaysBefore,
    DateTime? createdAt,
  }) {
    return LunarEvent(
      id: id ?? this.id,
      title: title ?? this.title,
      type: type ?? this.type,
      solarDate: solarDate ?? this.solarDate,
      lunarDay: lunarDay ?? this.lunarDay,
      lunarMonth: lunarMonth ?? this.lunarMonth,
      lunarYear: lunarYear ?? this.lunarYear,
      description: description ?? this.description,
      notifyDaysBefore: notifyDaysBefore ?? this.notifyDaysBefore,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  @override
  List<Object?> get props => [
    id, title, type, solarDate, lunarDay, lunarMonth, lunarYear, description, notifyDaysBefore, createdAt
  ];
}
