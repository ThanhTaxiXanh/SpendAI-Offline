// lib/core/entities/wallet.dart
import 'package:equatable/equatable.dart';

class Wallet extends Equatable {
  final String id;
  final String name;
  final String currency;
  final int balance;
  final String icon;
  final bool isVisible;
  final DateTime createdAt;

  const Wallet({
    required this.id,
    required this.name,
    required this.currency,
    required this.balance,
    required this.icon,
    required this.isVisible,
    required this.createdAt,
  });

  Wallet copyWith({
    String? id,
    String? name,
    String? currency,
    int? balance,
    String? icon,
    bool? isVisible,
    DateTime? createdAt,
  }) {
    return Wallet(
      id: id ?? this.id,
      name: name ?? this.name,
      currency: currency ?? this.currency,
      balance: balance ?? this.balance,
      icon: icon ?? this.icon,
      isVisible: isVisible ?? this.isVisible,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  @override
  List<Object?> get props => [id, name, currency, balance, icon, isVisible, createdAt];
}
