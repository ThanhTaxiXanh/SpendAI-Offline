// lib/core/entities/transaction.dart
import 'package:equatable/equatable.dart';

enum TransactionType { expense, income, transfer }

class Transaction extends Equatable {
  final String id;
  final String walletId;
  final String? categoryId;
  final TransactionType type;
  final int amount;
  final String currency;
  final DateTime date;
  final String? note;
  final String? relatedWalletId;
  final DateTime createdAt;

  const Transaction({
    required this.id,
    required this.walletId,
    this.categoryId,
    required this.type,
    required this.amount,
    required this.currency,
    required this.date,
    this.note,
    this.relatedWalletId,
    required this.createdAt,
  });

  Transaction copyWith({
    String? id,
    String? walletId,
    String? categoryId,
    TransactionType? type,
    int? amount,
    String? currency,
    DateTime? date,
    String? note,
    String? relatedWalletId,
    DateTime? createdAt,
  }) {
    return Transaction(
      id: id ?? this.id,
      walletId: walletId ?? this.walletId,
      categoryId: categoryId ?? this.categoryId,
      type: type ?? this.type,
      amount: amount ?? this.amount,
      currency: currency ?? this.currency,
      date: date ?? this.date,
      note: note ?? this.note,
      relatedWalletId: relatedWalletId ?? this.relatedWalletId,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  @override
  List<Object?> get props => [
    id, walletId, categoryId, type, amount, currency, date, note, relatedWalletId, createdAt
  ];
}
