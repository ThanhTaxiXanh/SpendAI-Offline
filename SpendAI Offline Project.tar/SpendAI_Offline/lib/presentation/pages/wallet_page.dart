// lib/presentation/pages/wallet_page.dart
import 'package:flutter/material.dart';
import '../../data/database/app_database.dart';

class WalletPage extends StatefulWidget {
  final AppDatabase database;

  const WalletPage({Key? key, required this.database}) : super(key: key);

  @override
  State<WalletPage> createState() => _WalletPageState();
}

class _WalletPageState extends State<WalletPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Quản lý Ví'),
      ),
      body: FutureBuilder(
        future: widget.database.getAllWallets() as Future<List<dynamic>>,
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final wallets = snapshot.data as List;
          if (wallets.isEmpty) {
            return Center(
              child: Text(
                'Chưa có ví nào',
                style: Theme.of(context).textTheme.bodyLarge,
              ),
            );
          }

          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: wallets.length,
            itemBuilder: (context, index) {
              final wallet = wallets[index] as dynamic;
              return Card(
                margin: const EdgeInsets.only(bottom: 12),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            (wallet as dynamic).name as String,
                            style: Theme.of(context).textTheme.titleLarge,
                          ),
                          Text(
                            (wallet as dynamic).icon as String,
                            style: const TextStyle(fontSize: 24),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(
                        '${(wallet as dynamic).balance} ${(wallet as dynamic).currency}',
                        style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                          color: Colors.green,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _showAddWalletDialog,
        child: const Icon(Icons.add),
      ),
    );
  }

  void _showAddWalletDialog() {
    final nameController = TextEditingController();
    final currencyController = TextEditingController(text: 'VND');
    final iconController = TextEditingController(text: '💰');

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Thêm Ví'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameController,
                decoration: const InputDecoration(labelText: 'Tên Ví'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: currencyController,
                decoration: const InputDecoration(labelText: 'Tiền tệ'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: iconController,
                decoration: const InputDecoration(labelText: 'Icon'),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Hủy'),
          ),
          ElevatedButton(
            onPressed: () async {
              await widget.database.into(widget.database.wallets).insert(
                WalletsCompanion(
                  id: Value(DateTime.now().millisecondsSinceEpoch.toString()),
                  name: Value(nameController.text),
                  currency: Value(currencyController.text),
                  icon: Value(iconController.text),
                  balance: const Value(0),
                  isVisible: const Value(true),
                  createdAt: Value(DateTime.now()),
                ),
              );
              if (mounted) {
                Navigator.pop(context);
                setState(() {});
              }
            },
            child: const Text('Thêm'),
          ),
        ],
      ),
    );
  }
}
