// lib/presentation/pages/transaction_page.dart
import 'package:flutter/material.dart';
import '../../data/database/app_database.dart';
import '../../domain/intelligence/voice_parser.dart';

class TransactionPage extends StatefulWidget {
  final AppDatabase database;

  const TransactionPage({Key? key, required this.database}) : super(key: key);

  @override
  State<TransactionPage> createState() => _TransactionPageState();
}

class _TransactionPageState extends State<TransactionPage> {
  final _amountController = TextEditingController();
  final _noteController = TextEditingController();
  late String _selectedWalletId;
  late String _selectedCategoryId;
  String _selectedType = 'expense';

  @override
  void initState() {
    super.initState();
    _loadDefaults();
  }

  Future<void> _loadDefaults() async {
    final wallets = await widget.database.getAllWallets() as List<dynamic>;
    if (wallets.isNotEmpty && mounted) {
      setState(() {
        _selectedWalletId = (wallets.first as dynamic).id as String;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Giao dịch'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Type Toggle
          SegmentedButton<String>(
            segments: const [
              ButtonSegment(value: 'income', label: Text('Chi tiêu')),
              ButtonSegment(value: 'income', label: Text('Thu nhập')),
              ButtonSegment(value: 'transfer', label: Text('Chuyển tiền')),
            ],
            selected: {_selectedType},
            onSelectionChanged: (Set<String> value) {
              setState(() => _selectedType = value.first);
            },
          ),
          const SizedBox(height: 20),
          
          // Amount
          TextField(
            controller: _amountController,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(
              labelText: 'Số tiền',
              prefixText: '₫',
            ),
          ),
          const SizedBox(height: 12),
          
          // Note
          TextField(
            controller: _noteController,
            decoration: const InputDecoration(
              labelText: 'Ghi chú',
            ),
          ),
          const SizedBox(height: 12),
          
          // Wallet Selector
          FutureBuilder(
            future: widget.database.getAllWallets() as Future<List<dynamic>>,
            builder: (context, snapshot) {
              if (!snapshot.hasData) {
                return const SizedBox.shrink();
              }
              final wallets = snapshot.data as List;
              return DropdownButton<String>(
                value: _selectedWalletId.isEmpty && wallets.isNotEmpty 
                    ? (wallets.first as dynamic).id as String
                    : _selectedWalletId,
                isExpanded: true,
                items: wallets
                    .map((w) => DropdownMenuItem(
                      value: (w as dynamic).id as String,
                      child: Text((w as dynamic).name as String),
                    ))
                    .toList(),
                onChanged: (value) {
                  if (value != null) {
                    setState(() => _selectedWalletId = value);
                  }
                },
              );
            },
          ),
          const SizedBox(height: 20),
          
          // Voice Input Button
          ElevatedButton.icon(
            onPressed: _showVoiceInputDialog,
            icon: const Icon(Icons.mic),
            label: const Text('Nhập giọng nói'),
          ),
          const SizedBox(height: 12),
          
          // Save Button
          ElevatedButton(
            onPressed: _saveTransaction,
            child: const Text('Lưu giao dịch'),
          ),
        ],
      ),
    );
  }

  void _showVoiceInputDialog() {
    final voiceController = TextEditingController();
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Ghi âm giao dịch'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: voiceController,
              decoration: const InputDecoration(
                labelText: 'Ví dụ: Chi 50000 đ mua cà phê',
                maxLines: 3,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Hủy'),
          ),
          ElevatedButton(
            onPressed: () {
              final parsed = VoiceTransactionParser.parse(voiceController.text);
              if (parsed != null) {
                setState(() {
                  _amountController.text = parsed.amount.toString();
                  _noteController.text = parsed.note ?? parsed.category;
                  _selectedType = parsed.type;
                });
                Navigator.pop(context);
              }
            },
            child: const Text('Phân tích'),
          ),
        ],
      ),
    );
  }

  Future<void> _saveTransaction() async {
    if (_amountController.text.isEmpty || _selectedWalletId.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Điền đầy đủ thông tin')),
      );
      return;
    }

    final amount = int.tryParse(_amountController.text) ?? 0;
    if (amount <= 0) return;

    await widget.database.into(widget.database.transactions).insert(
      TransactionsCompanion(
        id: Value(DateTime.now().millisecondsSinceEpoch.toString()),
        walletId: Value(_selectedWalletId),
        type: Value(_selectedType),
        amount: Value(amount),
        currency: const Value('VND'),
        date: Value(DateTime.now()),
        note: Value(_noteController.text),
        createdAt: Value(DateTime.now()),
      ),
    );

    _amountController.clear();
    _noteController.clear();

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Giao dịch đã được lưu')),
      );
    }
  }

  @override
  void dispose() {
    _amountController.dispose();
    _noteController.dispose();
    super.dispose();
  }
}
