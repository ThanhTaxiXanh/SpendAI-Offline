// lib/presentation/pages/settings_page.dart
import 'package:flutter/material.dart';
import '../../data/database/app_database.dart';

class SettingsPage extends StatefulWidget {
  final AppDatabase database;

  const SettingsPage({Key? key, required this.database}) : super(key: key);

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Cài đặt'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Categories Section
          _buildSectionTitle('Danh mục'),
          const SizedBox(height: 12),
          FutureBuilder(
            future: widget.database.getAllCategories() as Future<List<dynamic>>,
            builder: (context, snapshot) {
              if (!snapshot.hasData) {
                return const SizedBox.shrink();
              }
              final categories = snapshot.data as List;
              return Column(
                children: [
                  ...categories.map((cat) => Card(
                    margin: const EdgeInsets.only(bottom: 8),
                    child: ListTile(
                      title: Text((cat as dynamic).name as String),
                      trailing: Text((cat as dynamic).icon as String),
                    ),
                  )),
                  ElevatedButton.icon(
                    onPressed: _showAddCategoryDialog,
                    icon: const Icon(Icons.add),
                    label: const Text('Thêm Danh mục'),
                  ),
                ],
              );
            },
          ),
          const SizedBox(height: 24),
          
          // Backup Section
          _buildSectionTitle('Sao lưu'),
          const SizedBox(height: 12),
          ElevatedButton.icon(
            onPressed: _backupDatabase,
            icon: const Icon(Icons.cloud_upload),
            label: const Text('Sao lưu dữ liệu'),
          ),
          const SizedBox(height: 12),
          ElevatedButton.icon(
            onPressed: _restoreDatabase,
            icon: const Icon(Icons.cloud_download),
            label: const Text('Khôi phục dữ liệu'),
          ),
          const SizedBox(height: 24),
          
          // About Section
          _buildSectionTitle('Thông tin'),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'SpendAI Offline v1.0.0',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Ứng dụng quản lý tài chính thông minh ngoại tuyến',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Text(
      title,
      style: Theme.of(context).textTheme.titleLarge,
    );
  }

  void _showAddCategoryDialog() {
    final nameController = TextEditingController();
    final iconController = TextEditingController(text: '📁');
    String selectedType = 'expense';

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Thêm Danh mục'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameController,
                decoration: const InputDecoration(labelText: 'Tên danh mục'),
              ),
              const SizedBox(height: 12),
              DropdownButton<String>(
                value: selectedType,
                isExpanded: true,
                items: const [
                  DropdownMenuItem(value: 'expense', child: Text('Chi tiêu')),
                  DropdownMenuItem(value: 'income', child: Text('Thu nhập')),
                ],
                onChanged: (value) {
                  if (value != null) {
                    selectedType = value;
                  }
                },
              ),
              const SizedBox(height: 12),
              TextField(
                controller: iconController,
                decoration: const InputDecoration(labelText: 'Icon'),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Hủy'),
          ),
          ElevatedButton(
            onPressed: () async {
              await widget.database.into(widget.database.categories).insert(
                CategoriesCompanion(
                  id: Value(DateTime.now().millisecondsSinceEpoch.toString()),
                  name: Value(nameController.text),
                  type: Value(selectedType),
                  icon: Value(iconController.text),
                  color: const Value('#FF5252'),
                  createdAt: Value(DateTime.now()),
                ),
              );
              if (mounted) {
                Navigator.pop(context);
                setState(() {});
              }
            },
            child: const Text('Thêm'),
          ),
        ],
      ),
    );
  }

  Future<void> _backupDatabase() async {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Sao lưu dữ liệu thành công')),
    );
  }

  Future<void> _restoreDatabase() async {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Khôi phục dữ liệu thành công')),
    );
  }
}
