// lib/presentation/pages/home_page.dart
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../data/database/app_database.dart';
import '../../domain/intelligence/intelligence_engines.dart';
import 'wallet_page.dart';
import 'transaction_page.dart';
import 'calendar_page.dart';
import 'settings_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _selectedIndex = 0;
  late AppDatabase database;
  late List<Widget> _pages;

  @override
  void initState() {
    super.initState();
    database = AppDatabase();
    _pages = [
      _buildOverviewPage(),
      CalendarPage(database: database),
      TransactionPage(database: database),
      WalletPage(database: database),
      SettingsPage(database: database),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: (index) => setState(() => _selectedIndex = index),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Tổng quan'),
          BottomNavigationBarItem(icon: Icon(Icons.calendar_today), label: 'Lịch'),
          BottomNavigationBarItem(icon: Icon(Icons.add_circle), label: 'Giao dịch'),
          BottomNavigationBarItem(icon: Icon(Icons.wallet), label: 'Ví'),
          BottomNavigationBarItem(icon: Icon(Icons.settings), label: 'Cài đặt'),
        ],
      ),
    );
  }

  Widget _buildOverviewPage() {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 40),
            Text(
              'Tổng quan Tài chính',
              style: Theme.of(context).textTheme.headlineLarge,
            ),
            const SizedBox(height: 24),
            FutureBuilder(
              future: database.getAllWallets() as Future<List<dynamic>>,
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }
                final wallets = snapshot.data as List;
                int totalBalance = 0;
                for (final wallet in wallets) {
                  totalBalance += (wallet as dynamic).balance as int;
                }

                return Card(
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Tổng số dư',
                          style: Theme.of(context).textTheme.bodyMedium,
                        ),
                        const SizedBox(height: 8),
                        Text(
                          '${totalBalance.toString().replaceAllMapped(
                            RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'),
                            (Match m) => '${m[1]},',
                          )}đ',
                          style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                            color: Colors.green,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
            const SizedBox(height: 24),
            Text(
              'Insights (Thông tin kinh tế)',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 12),
            FutureBuilder(
              future: Future.wait([
                database.getAllCategories() as Future<List<dynamic>>,
                (database.select(database.transactions)).get(),
              ]),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const SizedBox.shrink();
                }
                
                final categories = snapshot.data?[0] as List? ?? [];
                final transactions = snapshot.data?[1] as List? ?? [];

                if (categories.isEmpty || transactions.isEmpty) {
                  return Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Text(
                        '📊 Thêm giao dịch để xem insights',
                        style: Theme.of(context).textTheme.bodyMedium,
                      ),
                    ),
                  );
                }

                final insights = InsightGenerator.generateInsights(
                  transactions.cast(),
                  categories.cast(),
                  10000000,
                );

                return Column(
                  children: insights
                      .map((insight) => Card(
                        margin: const EdgeInsets.only(bottom: 12),
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Text(
                            insight['message'] as String,
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                        ),
                      ))
                      .toList(),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
