# SpendAI Offline - Production-Ready Financial Intelligence Ecosystem

## Overview
SpendAI Offline is a complete, offline-first personal financial management system with integrated AI intelligence engines, lunar calendar support, multi-wallet management, and encrypted cloud backup.

**Version:** 1.0.0  
**Status:** Production-Ready  
**Platform:** Flutter (Android + iOS)

---

## 🎯 Core Features

### 1. **Lunar Calendar System**
- Display solar and lunar dates with Vietnamese weekday names
- Support for both solar and lunar event creation
- Configurable notifications (days before event)
- Integrated event management with visual calendar grid

### 2. **Multi-Wallet Management**
- Create/Edit/Delete multiple wallets
- Support for different currencies (default: VND)
- Real-time balance tracking
- Transfer between wallets
- Wallet visibility toggle

### 3. **Transaction Management**
- Three transaction types: Expense, Income, Transfer
- Voice-to-text quick entry with Vietnamese NLP parsing
- Category-based organization
- Full CRUD operations
- Transaction history and filtering

### 4. **Category System**
- Pre-configured expense and income categories
- Custom category creation with icon/color selection
- Category-based analytics and filtering

### 5. **Crypto Watchlist** (Max 5)
- Real-time crypto price tracking via CoinGecko API
- Offline caching with last-known prices
- 24h change percentage
- Manual price fallback entry

### 6. **Vietnam Gold Price Tracking**
- Configurable price source
- Manual entry fallback
- Local caching with timestamps
- Optional trend visualization

### 7. **Calendar History View**
- Monthly grid display with daily income/expense
- Day-level transaction detail view
- Monthly summary card
- Wallet filtering capabilities

### 8. **Analytics & Reports**
- Time-range filtering (Week/Month/Year/Custom)
- Wallet-level filtering
- Donut charts for category breakdown
- Horizontal bar charts for comparisons
- Total income/expense/net calculations

### 9. **AI Financial Intelligence Engine** (Self-Evolving)

#### A. **Behavior Profile Engine**
- Analyzes spending patterns per category
- Calculates rolling averages and frequency
- Generates risk scores (0.0-1.0)

#### B. **Recurring Detection Engine**
- Identifies recurring transactions
- Estimates payment frequency (daily/weekly/monthly)
- Calculates confidence scores
- Predicts next occurrence

#### C. **Anomaly Detection Engine**
- Detects unusual spending spikes (Z-score > 2.0)
- Compares against 30-day baseline
- Calculates severity metrics

#### D. **Budget Risk Predictor**
- Forecasts month-end overspending probability
- Uses logistic regression
- Configurable budget thresholds

#### E. **Spending Forecast Engine**
- Projects end-of-month balance
- Linear regression-based forecasting
- Daily rate calculation

#### F. **Insight Generator**
- Generates 5 prioritized insights per day
- Categories: Warning, Suggestion, Info
- Vietnamese language output
- Severity-based ranking

### 10. **Google Drive Backup & Restore**
- Manual backup to Google Drive
- OAuth 2.0 authentication
- AES-256 encryption (optional)
- PBKDF2 key derivation
- Integrity hash validation
- One-click restore functionality

### 11. **Local Notifications**
- Lunar event reminders (configurable days before)
- Low wallet balance alerts
- AI-generated insights notifications
- User-configurable notification settings

### 12. **Home Screen Widget System**
- 2x2 and 4x2 widget sizes (Android/iOS)
- Display current date, lunar date, weekday
- Show upcoming events
- Optional balance display
- Real-time update on app interaction

---

## 🏗️ Architecture

### Clean Architecture Implementation
```
lib/
├── core/
│   ├── entities/          # Domain entities (Wallet, Transaction, etc.)
│   └── utils/             # Common utilities
├── data/
│   ├── database/          # Drift database schema & queries
│   └── repositories/      # Data access layer implementations
├── domain/
│   ├── intelligence/      # AI engines & voice parser
│   └── usecases/          # Business logic
├── presentation/
│   ├── pages/             # Main screen pages
│   ├── widgets/           # Reusable UI components
│   ├── controllers/       # State management (GetX)
│   └── theme/             # App theming
└── main.dart              # App entry point
```

### Technology Stack
- **State Management:** GetX, Provider, Riverpod
- **Database:** Drift (type-safe SQLite wrapper)
- **Networking:** HTTP, Google APIs
- **Local Storage:** GetStorage
- **UI Components:** Flutter Material 3
- **Charts:** FL Chart
- **Voice:** speech_to_text (on-device)
- **Encryption:** PointyCastle, crypto
- **Notifications:** flutter_local_notifications
- **Calendar:** table_calendar, lunar

---

## 📦 Installation & Setup

### Prerequisites
- Flutter SDK 3.0.0 or higher
- Dart SDK 3.0.0 or higher
- Android SDK 21+ (for Android)
- Xcode 12+ (for iOS)

### Step 1: Clone/Extract Project
```bash
# Extract the ZIP file
unzip SpendAI_Offline_Project.zip
cd SpendAI_Offline
```

### Step 2: Install Dependencies
```bash
flutter pub get
```

### Step 3: Build Drift Database
```bash
flutter pub run build_runner build
```

### Step 4: Configure Google Drive OAuth (Optional)

#### For Android:
1. Go to [Google Cloud Console](https://console.cloud.google.com)
2. Create a new project
3. Enable Google Drive API
4. Create OAuth 2.0 credentials (Android app)
5. Add SHA-1 fingerprint from your release key:
   ```bash
   keytool -list -v -keystore ~/.android/debug.keystore -alias androiddebugkey -storepass android -keypass android
   ```
6. Update `android/app/src/main/AndroidManifest.xml` with OAuth client ID

#### For iOS:
1. Follow steps 1-3 above for Google Cloud
2. Create OAuth 2.0 credentials (iOS app)
3. Add iOS Bundle ID: `com.spendai.spendai-offline`
4. Configure URL scheme in Xcode project

### Step 5: Android Widget Setup

Add to `android/app/src/main/AndroidManifest.xml`:
```xml
<receiver android:name="com.example.home_widget.HomeWidgetProvider"
    android:exported="true">
    <intent-filter>
        <action android:name="android.appwidget.action.APPWIDGET_UPDATE" />
    </intent-filter>
    <meta-data android:name="android.appwidget.provider"
        android:resource="@xml/widget_info" />
</receiver>
```

### Step 6: iOS AppGroup Setup

In Xcode:
1. Select project → Signing & Capabilities
2. Add "App Groups" capability
3. Set group ID: `group.com.spendai.spendai-offline`
4. Apply to both app and widget target

### Step 7: Enable AES Backup Encryption (Optional)

In `lib/core/utils/encryption.dart`, configure PBKDF2 parameters:
```dart
static const int ITERATIONS = 100000;  // NIST recommendation
static const int KEY_LENGTH = 32;      // 256-bit
static const int SALT_LENGTH = 16;     // 128-bit
```

---

## 🚀 Building & Deployment

### Debug Build
```bash
flutter run
```

### Release Build - Android
```bash
flutter build apk --release
# or for App Bundle:
flutter build appbundle --release
```

Output: `build/app/outputs/flutter-apk/app-release.apk`

### Release Build - iOS
```bash
flutter build ios --release
# Then open in Xcode and archive
open ios/Runner.xcworkspace
```

---

## 🧪 Testing

### Run All Tests
```bash
flutter test
```

### Test Coverage
```bash
flutter test --coverage
```

### Specific Test File
```bash
flutter test test/domain/intelligence_engines_test.dart
```

---

## 📊 Database Schema

### Tables
- **wallets** - User financial accounts
- **categories** - Expense/Income categories
- **transactions** - All financial transactions
- **lunar_events** - Calendar events (solar & lunar)
- **crypto_watchlist** - Cryptocurrency tracking (max 5)
- **behavior_profiles** - AI behavior analysis data
- **recurring_patterns** - Detected recurring transactions
- **anomaly_logs** - Detected spending anomalies
- **insights** - Generated AI insights
- **plugin_registry** - Plugin system registry
- **feature_flags** - Feature toggle management

---

## 🔐 Security & Privacy

### Encryption
- ✅ AES-256-CBC for Google Drive backups
- ✅ PBKDF2 key derivation (100k iterations)
- ✅ Random salt (128-bit) + IV (128-bit)
- ✅ HMAC integrity validation

### Privacy
- ✅ 100% offline-first operation
- ✅ No data sent without user consent
- ✅ Local SQLite database only
- ✅ Optional encrypted backups

### Permissions Required
- `READ_EXTERNAL_STORAGE` (backup)
- `WRITE_EXTERNAL_STORAGE` (backup)
- `RECORD_AUDIO` (voice input - optional)
- `INTERNET` (Google Drive, crypto API - optional)

---

## 🎨 UI/UX Features

### Material Design 3
- Light and dark theme support
- Responsive layouts
- Smooth animations
- Custom color palette

### Accessibility
- Semantic labels for screen readers
- High contrast text
- Adjustable font sizes
- Keyboard navigation support

---

## 🔌 Plugin Architecture

### Registering a Plugin
```dart
await database.into(database.pluginRegistry).insert(
  PluginRegistryCompanion(
    id: Value(pluginId),
    name: Value('My Plugin'),
    version: Value('1.0.0'),
    isEnabled: const Value(true),
    installedAt: Value(DateTime.now()),
  ),
);
```

### Feature Flags
```dart
final isFeatureEnabled = await database
    .select(database.featureFlags)
    .where((f) => f.name.equals('feature_name'))
    .getSingleOrNull();
```

---

## 📈 Performance Metrics

- App Launch: < 2 seconds
- Widget Load: < 200ms
- Database Query: < 100ms (optimized indexes)
- Voice Parse: < 500ms (on-device)
- AI Engine: Isolated thread execution

---

## 🆘 Troubleshooting

### Build Issues

**"Cannot build after pubspec changes"**
```bash
flutter clean
flutter pub get
flutter pub run build_runner build
```

**"SQLite database locked"**
- Ensure only one app instance running
- Check for background tasks accessing database

### Runtime Issues

**"Google Drive OAuth fails"**
1. Verify client ID configuration
2. Check SHA-1 fingerprint matches
3. Enable Google Drive API in Cloud Console

**"Voice recognition not working"**
1. Check microphone permissions
2. Verify device supports speech_to_text
3. Test with Vietnamese language pack

**"Widgets not updating"**
1. Rebuild app after changes
2. Clear widget cache: `adb shell pm clear com.android.launcher`
3. On iOS: Remove and re-add widget

---

## 📝 Changelog

### v1.0.0 (Initial Release)
- ✅ Core wallet & transaction management
- ✅ Lunar calendar system
- ✅ AI intelligence engines (all 6)
- ✅ Voice transaction parsing
- ✅ Google Drive backup/restore
- ✅ Home screen widgets
- ✅ Crypto watchlist
- ✅ Analytics dashboard
- ✅ Full test coverage

---

## 🤝 Contributing

This is a production codebase. To extend:

1. Follow Clean Architecture patterns
2. Add unit tests for new features
3. Update documentation
4. Test on both Android and iOS

---

## 📄 License

MIT License - Free for personal and commercial use

---

## 📞 Support

For issues or questions:
- Check the troubleshooting section above
- Review code comments in relevant files
- Examine test files for usage examples
- Check GitHub Issues (if open-source)

---

## 🎓 Architecture Documentation

### Entity Relationships
```
Wallet ← Transaction → Category
             ↓
         LunarEvent (date-linked)
         
Crypto Watchlist (separate)
BehaviorProfile ← Transaction analysis
Insight ← AI Engines
```

### Data Flow
```
Transaction Input
    ↓
Voice Parser / Manual Entry
    ↓
Database Insert (Drift)
    ↓
AI Engines Process (Isolate)
    ↓
Insight Generation
    ↓
UI Update (GetX/Provider)
    ↓
Widget Sync
```

### AI Pipeline
```
Raw Transactions
    ↓
[BehaviorProfile] [RecurringDetection] [AnomalyDetection]
    ↓
[BudgetRisk] [SpendingForecast]
    ↓
InsightGenerator
    ↓
Prioritized Insights
```

---

## ✨ Special Features

### Voice Transaction Parsing
Supported phrases (Vietnamese):
- "Chi 50 nghìn mua cà phê" → Expense: 50K, Category: Coffee
- "Thu nhập 2 triệu lương" → Income: 2M, Category: Salary
- "Chuyển 100k cho anh" → Transfer: 100K

### Smart Categories
Pre-configured with icons and colors:
- 🍽️ Food / 🍵 Coffee / 🚗 Transport
- 🏪 Shopping / 💡 Utilities / 🎮 Entertainment
- 📚 Education / 💪 Health / 💰 Salary

### Lunar Calendar Integration
- Automatic lunar date calculation
- Vietnamese holidays support
- Configurable event notifications

---

## 🔮 Future Enhancements

Roadmap for v2.0+:
- ✨ Cloud sync across devices
- ✨ Multi-user households
- ✨ Advanced forecasting (ARIMA)
- ✨ OCR receipt scanning
- ✨ Cryptocurrency trading integration
- ✨ Real estate & investment tracking
- ✨ Machine learning budget optimization
- ✨ Natural language financial advisor

---

**Built with ❤️ for privacy-first financial freedom.**
