// test/domain/intelligence_engines_test.dart
import 'package:flutter_test/flutter_test.dart';
import 'package:spendai_offline/core/entities/transaction.dart';
import 'package:spendai_offline/core/entities/category.dart';
import 'package:spendai_offline/domain/intelligence/intelligence_engines.dart';

void main() {
  group('Intelligence Engines Tests', () {
    final mockTransactions = [
      Transaction(
        id: '1',
        walletId: 'wallet1',
        categoryId: 'food',
        type: TransactionType.expense,
        amount: 50000,
        currency: 'VND',
        date: DateTime.now().subtract(const Duration(days: 30)),
        createdAt: DateTime.now(),
      ),
      Transaction(
        id: '2',
        walletId: 'wallet1',
        categoryId: 'food',
        type: TransactionType.expense,
        amount: 55000,
        currency: 'VND',
        date: DateTime.now().subtract(const Duration(days: 23)),
        createdAt: DateTime.now(),
      ),
      Transaction(
        id: '3',
        walletId: 'wallet1',
        categoryId: 'food',
        type: TransactionType.expense,
        amount: 52000,
        currency: 'VND',
        date: DateTime.now().subtract(const Duration(days: 16)),
        createdAt: DateTime.now(),
      ),
      Transaction(
        id: '4',
        walletId: 'wallet1',
        categoryId: 'food',
        type: TransactionType.expense,
        amount: 150000, // Anomaly
        currency: 'VND',
        date: DateTime.now(),
        createdAt: DateTime.now(),
      ),
    ];

    test('BehaviorProfileEngine - calculates average and risk', () {
      final profile = BehaviorProfileEngine.analyzeBehavior(mockTransactions, 'food');
      
      expect(profile['avgAmount'], greaterThan(0));
      expect(profile['frequency'], greaterThan(0));
      expect(profile['riskScore'], greaterThanOrEqualTo(0.0));
      expect(profile['riskScore'], lessThanOrEqualTo(1.0));
    });

    test('RecurringDetectionEngine - detects weekly pattern', () {
      final recurring = RecurringDetectionEngine.detectRecurring(mockTransactions, 'food');
      
      expect(recurring, isNotNull);
      expect(recurring?['frequency'], equals('weekly'));
      expect(recurring?['confidence'], greaterThan(0.5));
    });

    test('AnomalyDetectionEngine - detects spending spike', () {
      final anomaly = AnomalyDetectionEngine.detectAnomaly(mockTransactions, 'food');
      
      expect(anomaly, isNotNull);
      expect(anomaly?['anomalyType'], equals('spike'));
      expect(anomaly?['zScore'], greaterThan(2.0));
    });

    test('BudgetRiskPredictor - calculates overspending probability', () {
      const monthlyBudget = 500000;
      final probability = BudgetRiskPredictor.calculateOverspendingProbability(
        mockTransactions,
        'food',
        monthlyBudget,
      );
      
      expect(probability, greaterThanOrEqualTo(0.0));
      expect(probability, lessThanOrEqualTo(1.0));
    });

    test('SpendingForecastEngine - forecasts end of month balance', () {
      const currentBalance = 10000000;
      final forecast = SpendingForecastEngine.forecastEndOfMonthBalance(
        mockTransactions,
        'wallet1',
        currentBalance,
      );
      
      expect(forecast, isA<int>());
    });

    test('InsightGenerator - generates insights', () {
      final categories = [
        const Category(
          id: 'food',
          name: 'Food',
          type: CategoryType.expense,
          icon: '🍽️',
          color: '#FF5252',
          createdAt: DateTime.now(),
        ),
      ];

      final insights = InsightGenerator.generateInsights(
        mockTransactions,
        categories,
        500000,
      );

      expect(insights, isNotEmpty);
      expect(insights.first['category'], isIn(['warning', 'suggestion', 'info']));
      expect(insights.first['message'], isNotEmpty);
    });
  });
}
