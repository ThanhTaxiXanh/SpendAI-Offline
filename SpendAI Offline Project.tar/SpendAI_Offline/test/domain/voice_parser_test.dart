// test/domain/voice_parser_test.dart
import 'package:flutter_test/flutter_test.dart';
import 'package:spendai_offline/domain/intelligence/voice_parser.dart';

void main() {
  group('VoiceTransactionParser Tests', () {
    test('parse - extracts amount from direct numbers', () {
      final result = VoiceTransactionParser.parse('chi 50000 dong');
      
      expect(result, isNotNull);
      expect(result?.amount, equals(50000));
    });

    test('parse - detects expense type by default', () {
      final result = VoiceTransactionParser.parse('chi tien mua ca phe');
      
      expect(result, isNotNull);
      expect(result?.type, equals('expense'));
    });

    test('parse - detects income type', () {
      final result = VoiceTransactionParser.parse('luong 2 trieu');
      
      expect(result, isNotNull);
      expect(result?.type, equals('income'));
    });

    test('parse - extracts food category', () {
      final result = VoiceTransactionParser.parse('chi 50000 an com');
      
      expect(result, isNotNull);
      expect(result?.category, equals('food'));
    });

    test('parse - extracts transport category', () {
      final result = VoiceTransactionParser.parse('chi 100000 xang xe');
      
      expect(result, isNotNull);
      expect(result?.category, equals('transport'));
    });

    test('parse - returns null for invalid input', () {
      final result = VoiceTransactionParser.parse('hello world');
      
      expect(result, isNull);
    });

    test('parse - calculates confidence score', () {
      final result = VoiceTransactionParser.parse('chi 50000 mua ca phe');
      
      expect(result?.confidence, greaterThan(0.5));
      expect(result?.confidence, lessThanOrEqualTo(1.0));
    });

    test('parse - generates unique transaction IDs', () {
      final result1 = VoiceTransactionParser.parse('chi 50000');
      final result2 = VoiceTransactionParser.parse('chi 50000');
      
      expect(result1?.id, isNotEqualTo(result2?.id));
    });
  });
}
